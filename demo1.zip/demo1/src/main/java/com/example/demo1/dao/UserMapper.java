package com.example.demo1.dao;

import com.example.demo1.model.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
@Mapper
public interface UserMapper {
    // 返回所有用户
    List<User> findAll();
    User find(@Param("id")Integer id);
}
