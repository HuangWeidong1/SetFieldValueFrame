package com.example.demo1.dao;

import com.example.demo1.model.Order;
import com.example.demo1.model.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface OrderMapper {
    //返回所有订单
    List<Order> findAllOrder();
}
