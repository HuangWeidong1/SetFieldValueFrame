package com.example.demo1.controller;

import com.example.demo1.model.Order;
import com.example.demo1.sericeInterface.OrderService;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/orderbill")
public class OrderController {
    @Autowired
    OrderService orderService;
    @RequestMapping("/GetOrder")
    public String GetOrder(){
        List<Order> orders = orderService.findAll();
        String ordersStr = JSONArray.fromObject(orders).toString();
        return ordersStr;
    }
}
