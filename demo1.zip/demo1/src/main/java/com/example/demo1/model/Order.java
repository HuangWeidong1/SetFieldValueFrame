package com.example.demo1.model;

import com.example.demo1.annotation.NeedSetValue;
import com.example.demo1.dao.UserMapper;

public class Order {
    private Integer ID;
    private String OrderName;
    private String OrderDescription;
    private Integer OrderUserID;
    @NeedSetValue(beanClass = UserMapper.class,method = "find",param = "OrderUserID",TargetFiled = "UserName")
    private String OrderUserName;

    public Integer getID() {
        return ID;
    }

    public String getOrderName() {
        return OrderName;
    }

    public String getOrderDescription() {
        return OrderDescription;
    }

    public Integer getOrderUserID() {
        return OrderUserID;
    }

    public String getOrderUserName() {
        return OrderUserName;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public void setOrderName(String orderName) {
        OrderName = orderName;
    }

    public void setOrderDescription(String orderDescription) {
        OrderDescription = orderDescription;
    }

    public void setOrderUserID(Integer orderUserID) {
        OrderUserID = orderUserID;
    }

    public void setOrderUserName(String orderUserName) {
        OrderUserName = orderUserName;
    }
}
