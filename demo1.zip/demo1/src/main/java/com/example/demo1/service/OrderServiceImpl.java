package com.example.demo1.service;

import com.example.demo1.annotation.NeedSetValueFeild;
import com.example.demo1.dao.OrderMapper;
import com.example.demo1.model.Order;
import com.example.demo1.sericeInterface.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    OrderMapper orderMapper;

    @NeedSetValueFeild
    @Override
    public List<Order> findAll() {
        return orderMapper.findAllOrder();
    }
}
