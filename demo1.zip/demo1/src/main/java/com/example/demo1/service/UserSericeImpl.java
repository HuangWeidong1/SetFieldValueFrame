package com.example.demo1.service;

import com.example.demo1.dao.UserMapper;
import com.example.demo1.model.User;
import com.example.demo1.sericeInterface.UserSerice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserSericeImpl implements UserSerice {
    @Autowired
    private UserMapper userMapper;

    @Override
    public List<User> findAll() {
        return userMapper.findAll();
    }
}
