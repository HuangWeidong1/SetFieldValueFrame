package com.example.demo1.sericeInterface;

import com.example.demo1.model.Order;

import java.util.List;

public interface OrderService {
    List<Order> findAll();
}
