package com.example.demo1.aspect;

import com.example.demo1.util.BeanUtil;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Component
@Aspect
public class SetFeildValueAspect {

    @Autowired
    BeanUtil beanUtil;
    @Around("@annotation(com.example.demo1.annotation.NeedSetValueFeild)")
    public Object doSetFeildValue(ProceedingJoinPoint pjp) throws Throwable{
        Object ret = pjp.proceed();//执行yuan
        //将结果集设置结果中
        this.beanUtil.setFeildValueForCol((Collection) ret);
        return ret;
    }
}
